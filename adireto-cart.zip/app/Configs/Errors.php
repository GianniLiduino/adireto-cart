<?php
define('FIRST_NAME_REQUIRED', 'Insira um nome');
define('FIRST_NAME_INVALID', 'First name must contain only letters and spaces');
// define('LAST_NAME_REQUIRED', 'Last name is required');
define('LAST_NAME_INVALID', 'Last name must contain only letters and spaces');
define('EMAIL_REQUIRED', 'Insira um email.');
define('EMAIL_INVALID', 'Insira um email válido.');
define('PASSWORD_REQUIRED', 'Insira uma senha.');
define('PASSWORD_INVALID', 'A senha precisa ter mais de 8 caracteres, letras maiúsculas e minúsculas, um número e um caractere especial.');
define('CONFIRM_PASSWORD_REQUIRED', 'Insira a confirmação da senha.');
define('CONFIRM_PASSWORD_MISMATCH', 'As senhas não são iguais.');
