<?php
session_start();

require '../env.php';
require '../app/Configs/Errors.php';

require '../vendor/autoload.php';

require '../routes/web.php';
