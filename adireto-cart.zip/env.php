<?php

define('DB_HOST', 'Localhost');
define('DB_NAME', 'adireto_cart');
define('DB_USER', 'root');
define('DB_PASSWORD', '');