<?php

use App\Services\EmailServices;
use PHPUnit\Framework\TestCase;

class EmailServicesTest extends TestCase
{
    public function test_if_the_email_was_sent()
    {
        $mail = new EmailServices();
        $mail->sendEmailVerification('gianniliduinociuldin@gmail.com', 'Gianni');
    }
}
