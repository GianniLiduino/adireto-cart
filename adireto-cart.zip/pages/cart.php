<?php
require __DIR__ . './Layouts/html-top.php';
require __DIR__ . './Components/Header.php';
?>

<main>
    <?php require __DIR__ . './Components/SectionCart.php'; ?>
</main>

<?php
require __DIR__ . './Layouts/html-bottom.php';
